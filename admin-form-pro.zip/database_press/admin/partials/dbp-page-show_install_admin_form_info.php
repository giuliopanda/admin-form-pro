<?php
/**
 * Il template della pagina amministrativa
 *
 * @package  DbPress
 * 
 * @var String $render_content Il file dentro partial da caricare 
 */
namespace DbPress;
if (!defined('WPINC')) die;
?>
<div class="wrap">
   
    <div id="dbp_container" class="dbp-grid-container" >
        <div class="dbp-column-content">
            <div style="font-size:1.2rem; background:#FFF; border:1px solid #CCC; padding:1rem;">
            Attention the <a href="https://wordpress.org/plugins/admin-form/" target="blank">plugin admin form</a> is not installed or is not active. 
            </div>
        </div>
    </div>
</div>
